/* ==========================================================================
   SHARED SIDEBAR + HEADER BEHAVIOUR
   Include this on every page AFTER the shared header/sidebar markup.
   ========================================================================== */

(function () {
  const hamburger   = document.getElementById('hamburgerBtn');
  const sidebar      = document.getElementById('appSidebar');
  const mainContent  = document.getElementById('mainContent');
  const overlay      = document.getElementById('sidebarOverlay');
  const profileBtn    = document.getElementById('profileBtn');
  const profileMenu   = document.getElementById('profileDropdown');

  function isMobile() { return window.innerWidth <= 900; }

  function toggleSidebar() {
    if (isMobile()) {
      sidebar.classList.toggle('mobile-open');
      overlay.classList.toggle('show');
    } else {
      sidebar.classList.toggle('collapsed');
      mainContent.classList.toggle('expanded');
    }
  }

  if (hamburger) hamburger.addEventListener('click', toggleSidebar);
  if (overlay) overlay.addEventListener('click', toggleSidebar);

  // Profile dropdown
  if (profileBtn) {
    profileBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      profileMenu.classList.toggle('open');
    });
    document.addEventListener('click', () => profileMenu.classList.remove('open'));
  }

  // Mark active nav link based on data-page attribute set on <body>
  const currentPage = document.body.getAttribute('data-page');
  document.querySelectorAll('.nav-link[data-page]').forEach(link => {
    if (link.getAttribute('data-page') === currentPage) {
      link.classList.add('active');
    }
  });
})();
