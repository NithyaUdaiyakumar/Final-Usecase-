/* ==========================================================================
   SPECIALIST / DOCTOR PROFILE — simple display grid
   Replace DOCTOR_DATA with a real API call when the backend is ready.
   ========================================================================== */

const DOCTOR_DATA = [
  { name:'Dr. Anil Verma',   spec:'Cardiologist',        exp:'14 yrs', phone:'+91 98765 43210', email:'anil.verma@curonex.in',   camps:12, patients:1480, active:true  },
  { name:'Dr. Kavita Rao',   spec:'General Physician',   exp:'9 yrs',  phone:'+91 91234 56780',  email:'kavita.rao@curonex.in',   camps:20, patients:2310, active:true  },
  { name:'Dr. Sameer Khan',  spec:'Ophthalmologist',     exp:'11 yrs', phone:'+91 99887 66554',  email:'sameer.khan@curonex.in',  camps:8,  patients:960,  active:true  },
  { name:'Dr. Priya Nair',   spec:'Pediatrician',        exp:'7 yrs',  phone:'+91 90123 45678',  email:'priya.nair@curonex.in',   camps:15, patients:1875, active:true  },
  { name:'Dr. Rohan Mehta',  spec:'Orthopedic Surgeon',  exp:'16 yrs', phone:'+91 98765 12340',  email:'rohan.mehta@curonex.in',  camps:10, patients:1120, active:false },
  { name:'Dr. Sneha Iyer',   spec:'Gynecologist',        exp:'12 yrs', phone:'+91 99001 22334',  email:'sneha.iyer@curonex.in',   camps:9,  patients:1050, active:true  },
  { name:'Dr. Arjun Desai',  spec:'Dermatologist',       exp:'6 yrs',  phone:'+91 97865 43201',  email:'arjun.desai@curonex.in',  camps:6,  patients:640,  active:true  },
  { name:'Dr. Meera Pillai', spec:'Dentist',             exp:'10 yrs', phone:'+91 98123 45670',  email:'meera.pillai@curonex.in', camps:13, patients:1560, active:true  },
  { name:'Dr. Vikram Singh', spec:'General Physician',   exp:'19 yrs', phone:'+91 90099 88776',  email:'vikram.singh@curonex.in', camps:22, patients:2740, active:false },
];

function initials(name) {
  return name.replace('Dr. ', '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

const grid = document.getElementById('doctorGrid');
const specSelect = document.getElementById('specFilter');

// populate specialization dropdown dynamically
const specs = [...new Set(DOCTOR_DATA.map(d => d.spec))].sort();
specSelect.innerHTML = `<option value="all">All</option>` + specs.map(s => `<option value="${s}">${s}</option>`).join('');

const state = { search:'', spec:'all' };

function render() {
  const filtered = DOCTOR_DATA.filter(d => {
    const matchesSearch = !state.search ||
      d.name.toLowerCase().includes(state.search) ||
      d.spec.toLowerCase().includes(state.search);
    const matchesSpec = state.spec === 'all' || d.spec === state.spec;
    return matchesSearch && matchesSpec;
  });

  grid.innerHTML = filtered.map(d => `
    <div class="card doctor-card">
      <div class="doctor-avatar">${initials(d.name)}</div>
      <h3 class="doctor-name">${d.name}</h3>
      <p class="doctor-spec">${d.spec}</p>

      <div class="doctor-meta">
        <div class="doctor-meta-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          ${d.exp} experience
        </div>
        <div class="doctor-meta-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          ${d.phone}
        </div>
        <div class="doctor-meta-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z" opacity="0"/><path d="M22 6l-10 7L2 6"/><rect x="2" y="4" width="20" height="16" rx="2"/></svg>
          ${d.email}
        </div>
      </div>

      <div class="doctor-stats">
        <div class="doctor-stat"><div class="num">${d.camps}</div><div class="lbl">Camps</div></div>
        <div class="doctor-stat"><div class="num">${d.patients.toLocaleString()}</div><div class="lbl">Patients Seen</div></div>
      </div>

      <span class="doctor-badge" style="${d.active ? '' : 'background:var(--c-warning-bg); color:var(--c-warning);'}">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
        ${d.active ? 'Active' : 'On Leave'}
      </span>
    </div>
  `).join('') || `<p style="grid-column:1/-1; text-align:center; color:var(--c-secondary); padding:40px;">No doctors found.</p>`;
}

document.getElementById('doctorSearch').addEventListener('input', (e) => {
  state.search = e.target.value.trim().toLowerCase();
  render();
});
specSelect.addEventListener('change', (e) => {
  state.spec = e.target.value;
  render();
});

render();
